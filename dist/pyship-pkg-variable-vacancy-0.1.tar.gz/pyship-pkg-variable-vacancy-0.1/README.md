# PyShip
A Python library to implement a "Battleship" mini game

## Scope
PyShip is intended to be a short game completed in a few number of turns, originally intended to be used in an IRC chat (specifically twitch.tv chat), though this is ideal in any minigame scenario

Constructing the PyShip will create a grid and place a single ship in the grid. A fire function can be called to check a space on the grid for the ship. If that space is hit, it is marked as such and a hit counter will count the number of valid hits. Once the number of hits equals the ship size, the player wins the game. If the player runs out of tries, the player loses the game

## Installation
In Progress
